package com.itwill.guest.controller;

import com.itwill.guest.GuestService;
public class GuestController {
	private GuestService guestService;
	public GuestController() {
		System.out.println(">>>GuestController");
	}
	
	

}













