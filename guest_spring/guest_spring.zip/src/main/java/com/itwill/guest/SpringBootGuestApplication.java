package com.itwill.guest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class SpringBootGuestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootGuestApplication.class, args);
	}

}
