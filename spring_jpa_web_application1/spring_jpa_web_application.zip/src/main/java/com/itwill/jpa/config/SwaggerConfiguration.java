package com.itwill.jpa.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfiguration {

   
}
