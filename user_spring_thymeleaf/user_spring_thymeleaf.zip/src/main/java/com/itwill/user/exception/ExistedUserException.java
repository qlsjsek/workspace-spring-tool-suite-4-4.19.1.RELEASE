package com.itwill.user.exception;

public class ExistedUserException extends Exception{
	public ExistedUserException(String msg) {
		super(msg);
	}
}
