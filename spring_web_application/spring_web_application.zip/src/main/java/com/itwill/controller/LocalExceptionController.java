package com.itwill.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.itwill.exception.BusinessException1;
import com.itwill.exception.BusinessException2;

public class LocalExceptionController {

	public String business_method1() throws BusinessException1 {

		return "";
	}

	public String business_method2() throws BusinessException2 {

		return "";
	}

	public String business_method3() {
		String name = null;
		int length = name.length();
		return "";
	}

}
