package com.itwill.exception;

public class BusinessException2 extends Exception{
	public BusinessException2(String msg) {
		super(msg);
	}
}
