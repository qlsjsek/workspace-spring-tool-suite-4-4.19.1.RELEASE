package com.itwill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
